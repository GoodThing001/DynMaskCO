# 当前扩展说明

先读[项目当前状态](项目当前状态.md)和[静态配送说明](docs/static_delivery/README.md)。工程规则见根AGENTS.md。旧动态取货与负结果只作为历史证据。
