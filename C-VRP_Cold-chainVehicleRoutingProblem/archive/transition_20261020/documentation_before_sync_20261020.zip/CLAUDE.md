# 当前工作区说明

请先读[AGENTS.md](AGENTS.md)和[静态配送说明](C-VRP_Cold-chainVehicleRoutingProblem/docs/static_delivery/README.md)。2026-10-20以前的长日志已作历史归档。
